from django.db import models


class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    bio = models.TextField(null=True)
    birth_date = models.DateField()
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=50)


class Reader(models.Model):
    gender = models.CharField(max_length=255)
    fav_genre = models.CharField(max_length=255)
    state = models.CharField(max_length=255)
    country = models.CharField(max_length=255)
    city = models.CharField(max_length=255)
    joining_date = models.DateField()
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    following = models.ManyToManyField('Reader')


class Admin(models.Model):
    admin_id = models.CharField(max_length=255, unique=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)


class Book(models.Model):
    book_name = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    description = models.TextField()
    number_of_pages = models.IntegerField()
    publish_date = models.DateField()
    language = models.CharField(max_length=255)
    approve_status = models.BooleanField(default=False)
    book_rating = models.DecimalField(max_digits=2, decimal_places=1)
    admin = models.ForeignKey(Admin, on_delete=models.PROTECT)
    will_read = models.ManyToManyField(Reader, related_name='reader_will_read')
    is_reading = models.ManyToManyField(Reader, related_name='reader_is_reading')
    have_read = models.ManyToManyField(Reader, related_name='reader_have_read')

class Rate(models.Model):
    readers = models.ManyToManyField(Reader)
    books = models.ManyToManyField(Book)
    rating = models.DecimalField(max_digits=2, decimal_places=1)
    