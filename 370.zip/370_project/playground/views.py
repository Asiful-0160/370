from django.shortcuts import render
from django.http import HttpResponse
from django.db.models import Count
from django.core.exceptions import ObjectDoesNotExist
from playground.models import *

def hello(request):
    try:
        queryset = Book.objects.filter(book_rating__gt=8).filter(admin__pk=1)
        
        # create & update
        # admin = Admin()
        # admin.pk = '15'
        # admin.admin_id = '15'
        # admin.save()

        # delete
        # admin = Admin(pk=11)
        # admin.delete()

        # amount = Book.objects.count()
        # return render(request, 'hello.html')
        # return HttpResponse(amount)

        return render(request, 'hello.html', {'Elements': list(queryset)})
    
    except ObjectDoesNotExist:
        return HttpResponse('hey')
