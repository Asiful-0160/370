INSERT INTO `370_project1`.playground_admin (admin_id, user_id) VALUES ('1', 1);
INSERT INTO `370_project1`.playground_admin (admin_id, user_id) VALUES ('12', 12);
INSERT INTO `370_project1`.playground_admin (admin_id, user_id) VALUES ('13', 14);
INSERT INTO `370_project1`.playground_admin (admin_id, user_id) VALUES ('15', 15);
INSERT INTO `370_project1`.playground_admin (admin_id, user_id) VALUES ('2', 2);
INSERT INTO `370_project1`.playground_admin (admin_id, user_id) VALUES ('3', 3);
INSERT INTO `370_project1`.playground_admin (admin_id, user_id) VALUES ('4', 4);
INSERT INTO `370_project1`.playground_admin (admin_id, user_id) VALUES ('5', 5);
